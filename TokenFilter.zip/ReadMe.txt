Fungsi :
• Untuk Merapikan & Menghapus Token Yang Sama

Kalau Script Tidak Bisa Di Jalankan,
Ganti Nama Script Sesuka Kalian Sampai Bisa Di Jalankan.


Author : exorcisT
Discord: https://discord.gg/7DjAZ8j
